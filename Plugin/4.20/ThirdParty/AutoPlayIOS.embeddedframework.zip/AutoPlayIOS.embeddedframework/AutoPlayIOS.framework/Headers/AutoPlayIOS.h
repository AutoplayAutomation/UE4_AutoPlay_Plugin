#import <UIKit/UIKit.h>
#import "UnityBridge.h"

//! Project version number for AutoPlayIOS.
FOUNDATION_EXPORT double AutoPlayIOSVersionNumber;

//! Project version string for AutoPlayIOS.
FOUNDATION_EXPORT const unsigned char AutoPlayIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AutoPlayIOS/PublicHeader.h>


